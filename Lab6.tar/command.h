#ifndef __COMMAND_CLASS__
#define __COMMAND_CLASS__

#include "composite.h"

class Command {
	protected:
		Base* root;
	
	public:
		Command() { };
		double execute() {
			return root->evaluate();
		};
		Base* get_root() {
			return root;
		};
};

class OpCommand : public Command {
    public:
	OpCommand(int value) {
        root = new Op(value);
    }

};

class AddCommand : public Command {
    public:
	AddCommand(Command* previous, int value) {
        Base* val = new Op(value);
        root = new Add(previous->get_root(), val);
    }
};

class SubCommand : public Command {
    public:
	SubCommand(Command* previous, int value) {
        Base* val = new Op(value);
        root = new Sub(previous->get_root(), val);
    }
};

class MultCommand : public Command {
    public:
	MultCommand(Command* previous, int value) {
        Base* val = new Op(value);
        root = new Mult(previous->get_root(), val);
    }
};

class SqrCommand : public Command {
    public:
	SqrCommand(Command* previous) {
        root = new Sqr(previous->get_root());
    }
};

#endif //__COMMAND_CLASS__
